﻿namespace SimpleWorker;

public record UserCreated(Guid UserId, string Email);